package adt.bst;

/**
 * 
 * Performs consistency validations within a BST instance
 * 
 * @author Claudio Campelo
 *
 * @param <T>
 */
public class BSTVerifierImpl<T extends Comparable<T>> implements BSTVerifier<T> {
	
	private BSTImpl<T> bst;

	public BSTVerifierImpl(BST<T> bst) {
		this.bst = (BSTImpl<T>) bst;
	}
	
	private BSTImpl<T> getBSt() {
		return bst;
	}

	@Override
	public boolean isBST() {
		return isBST(bst.getRoot());
	}

	private boolean isBST(BSTNode<T> root) {
		if(root.getLeft().isEmpty() && root.getRight().isEmpty()) {
			return true;
		}
		if(!root.getLeft().isEmpty() && root.getData().compareTo(root.getLeft().getData()) > 0) {
			if(!root.getRight().isEmpty() && root.getData().compareTo(root.getRight().getData()) > 0) {
				return true && this.isBST((BSTNode<T>) root.getLeft()) && this.isBST((BSTNode<T>) root.getRight());
			}
			else {
				return true && this.isBST((BSTNode<T>) root.getLeft());
			}
		}
		else if(!root.getRight().isEmpty() && root.getData().compareTo(root.getRight().getData()) > 0) {
			this.isBST((BSTNode<T>) root.getRight());
		}
		
		return false;
	}
	
}
